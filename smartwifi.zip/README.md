# SMARTWIFI – Wi‑Fi Voucher System (Vercel)

## إعداد سريع
1) أضف متغيرات البيئة في Vercel:
- MONGODB_URI  = رابط MongoDB Atlas
- MONGODB_DB   = smartwifi (اختياري)
- JWT_SECRET   = مفتاح عشوائي طويل
- ADMIN_USER   = admin
- ADMIN_PASS   = 123
